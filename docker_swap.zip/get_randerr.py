import numpy as np
from scipy.stats import norm
from scipy.interpolate import interp1d
import scipy.stats as st
import csv

def aprx_add (a, b, bits):
    carry = 1<<(bits-1);
    lor = a|b
    if(carry&a&b == carry): 
        lor=lor+(carry<<1)
    return lor


K = pow(2,31-4)-1
mask_l = 0x0000000f
mask_u = 0xfffffff0

for layer in ['conv1','conv2','fc1']:
	add_apx = np.array([])
	add_acc = np.array([])
	add_err = np.array([])

	nums = []

	f = open('/home/Documents/docker_swap/data/'+layer+'_add.csv', 'r')

	for line in f.readlines():
		out = line.split(";")

	for out2 in out:
		nums.append(map(int, out2.split(",")))

	f.close()

	print "file read"

	i = 0 
	#get accurate adds
	#get approx adds
	for row in nums:
		add_acc = np.append(add_acc, sum(row))
		a = row[0]
		for b in row[1:]:
			lower = aprx_add(a&mask_l, b&mask_l, 4)
			upper = (a&mask_u) + (b&mask_u)
			a = lower + upper
		add_apx = np.append(add_apx, a)
		i = i + 1
		if i % 10000 == 0:
			print i

	print "approx added"

	add_err = (add_acc - add_apx)/add_acc

	file_str = ""
	for i in range(add_acc.size-1):
		file_str = file_str+('{0},{1}\n'.format(int(add_acc[i]), int(add_apx[i])))

	print "result prepped"

	f = open('/home/Documents/docker_swap/data/'+layer+'_add_result_4.csv', 'w')
	f.write(file_str)
	f.close()

	print "result wrote"

	file_str=""
	for n in add_err[:-1]:
		file_str = file_str+('{0:.20f},'.format(n))
	file_str = file_str + ('{0:.20f}'.format(add_err[-1]))

	print "err prepped"

	f = open('/home/Documents/docker_swap/data/'+layer+'_add_perr_4.csv', 'w')
	f.write(file_str)
	f.close()

	print "err wrote"

	print max(add_err)
	print np.mean(add_err)


