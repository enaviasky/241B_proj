import numpy as np
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
%matplotlib inline
from scipy.stats import norm
from scipy.interpolate import interp1d
import scipy.stats as st

def aprx_add (a, b, bits):
    carry = 1<<(bits-1);
    lor = a|b
    if(carry&a&b == carry): 
        lor=lor+(carry<<1)
        
    return lor
