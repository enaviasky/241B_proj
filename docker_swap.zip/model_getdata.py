from pylab import *
import sys
import caffe
from caffe import layers as L, params as P
import os
import numpy as np
import csv

caffe_root = '/opt/caffe/'

sys.path.insert(0, caffe_root + 'python')
os.chdir(caffe_root)
# back to examples
os.chdir('examples')

#Setup caffe in CPU mode
caffe.set_mode_cpu()

#Get files for net shape and weights
model_def = '/docker_swap/lenet_auto_test.prototxt'#caffe_root + 'examples/mnist/lenet_auto_test.prototxt'
model_weights = '/docker_swap/lenet.caffemodel' #caffe_root + 'models/lenet.caffemodel'

net = caffe.Net(model_def,      # defines the structure of the model
                model_weights,  # contains the trained weights
                caffe.TEST)     # use test mode (e.g., don't perform dropout)

net.forward()

#GET WEIGHTS
layer_str = 'fc1'

data = net.params[layer_str][0].data.flatten()
i = np.nonzero(data)
data = data[i]	

K = pow(2,31-4)-1
data = (data*K).astype(int)

with open('/docker_swap/data/'+layer_str+'_unsigned_weights.csv', 'w') as csvfile:
	writer = csv.writer(csvfile,  delimiter=',')
	writer.writerow(abs(data))

print (size(data))
if max(abs(data)) > (pow(2, 32)-1):
	print('Change your K val, you suck')




#GET DATA
#layer_str = 'data'

#data = np.trim_zeros(net.blobs[layer_str].data.flatten()) 
#i = np.nonzero(data)
#data = data[i]

#for i in range(100):
#	net.forward()
#	data = np.hstack((np.trim_zeros(net.blobs[layer_str].data.flatten()) , data))
#	i = np.nonzero(data)
#	data = data[i]	

#K = pow(2,31-4)-1
#data = (data*K).astype(int)

#with open('/docker_swap/data/'+layer_str+'_unsigned_0.csv', 'w') as csvfile:
#	writer = csv.writer(csvfile,  delimiter=',')
#	writer.writerow(abs(data))

#print (size(data))
#if max(abs(data)) > (pow(2, 32)-1):
#	print('Change your K val, you suck')

# max nums [1.0, 2.3937974, 5.6898022, 7.3406081]


