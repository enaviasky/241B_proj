import numpy as np
from scipy.stats import norm
from scipy.interpolate import interp1d
import scipy.stats as st
import csv

K = pow(2,31-4)-1
shift = 16
for mask in [0xfffc0000, 0xfff00000, 0xffc00000]:
	shift = shift +2
	for layer in ['conv1','conv2', 'fc1']:
		mult_apx = np.array([])
		mult_acc = np.array([])
		mult_err = np.array([])

		nums = []

		f = open('/home/Documents/docker_swap/data/'+layer+'_mult.csv', 'r')

		for line in f.readlines():
			out = line.split(";")

		for out2 in out:
			nums.append(map(int, out2.split(",")))

		f.close()

		i = 0
		for row in nums:
			mult = (row[0]*row[1])>>27
			mult_acc = np.append(mult_acc, mult if mult != 0 else 1)
			mult_apx = np.append(mult_apx, mult&mask if mult != 0 else 1) 
			i = i + 1
			if i % 100000 == 0:
				print i

		print "approx multed"

		mult_err = (mult_acc - mult_apx)/mult_acc

	

		file_str = ""
		for i in range(mult_acc.size-1):
			file_str = file_str+('{0},{1}\n'.format(int(mult_acc[i]), int(mult_apx[i])))

		print "result prepped"

		f = open('/home/Documents/docker_swap/data/'+layer+'_mult_result_'+str(shift)+'.csv', 'w')
		f.write(file_str)
		f.close()

		print "result wrote"

		file_str=""
		for n in mult_err[:-1]:
			file_str = file_str+('{0:.20f},'.format(n))
		file_str = file_str + ('{0:.20f}'.format(mult_err[-1]))

		print "err prepped"

		f = open('/home/Documents/docker_swap/data/'+layer+'_mult_perr_'+str(shift)+'.csv', 'w')
		f.write(file_str)
		f.close()

		print "err wrote"

		print 'max, mean for '+layer+' '+str(shift)+'b'
		print max(mult_err)
		print np.mean(mult_err)

