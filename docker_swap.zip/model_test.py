from pylab import *
import sys
import caffe
from caffe import layers as L, params as P
import os
import numpy as np

caffe_root = '/opt/caffe/'

sys.path.insert(0, caffe_root + 'python')
os.chdir(caffe_root)
# back to examples
os.chdir('examples')

#Setup caffe in CPU mode
caffe.set_mode_cpu()

#Get files for net shape and weights
model_def = '/docker_swap/lenet_auto_test.prototxt'#caffe_root + 'examples/mnist/lenet_auto_test.prototxt'
model_weights = '/docker_swap/lenet.caffemodel' #caffe_root + 'models/lenet.caffemodel'

net = caffe.Net(model_def,      # defines the structure of the model
                model_weights,  # contains the trained weights
                caffe.TEST)     # use test mode (e.g., don't perform dropout)

#print 'Testing...'
#correct = 0
#for test_it in range(500):
#    net.forward()
#    correct += sum(net.blobs['score'].data.argmax(1) == net.blobs['label'].data)

#test_acc = correct / 5e4
#print test_acc


print 'Testing...'
correct = 0

def get_mult_err(layer, sized): 
	err = np.array([])
	i = 0
	f = open('/docker_swap/data/'+layer+'_mult_perr_16.csv', 'r')

	for line in f.readlines():
		err = np.append(err, map(float,line.split(",")))

	f.close()

	err = 1-err
	err_n = err
	while err_n.size < sized :
		err_n = np.append(err_n, err)

	return err_n[:sized]

def get_add_err(layer, sized): 
	err = np.array([])
	i = 0
	f = open('/docker_swap/data/'+layer+'_add_perr_4.csv', 'r')

	for line in f.readlines():
		err = np.append(err, map(float,line.split(",")))

	f.close()

	err = 1-err
	err_n = err
	while err_n.size < sized :
		err_n = np.append(err_n, err)

	return err_n[:sized]

conv1err = get_add_err('conv1', 100*20*24*24).reshape(100, 20, 24, 24)# * get_mult_err('conv1', 100*20*24*24).reshape(100, 20, 24, 24)
print "conv1 err {0}".format(conv1err[0][0][0][0])
conv2err = get_add_err('conv2', 100*50*8*8).reshape(100, 50, 8, 8) #* get_mult_err('conv2', 100*50*8*8).reshape(100, 50, 8, 8)
print "conv2 err {0}".format(conv2err[0][0][0][0])
fc1err = get_add_err('fc1', 100*500).reshape(100, 500) #* get_mult_err('fc1', 100*500).reshape(100, 500)
print "fc1 err {0}".format(fc1err[0][0])



for test_it in range(500):
	net.forward(end='conv1')
	net.blobs['conv1'].data[...] = net.blobs['conv1'].data[...] *conv1err
	net.forward(start='pool1', end='conv2')
	net.blobs['conv2'].data[...] = net.blobs['conv2'].data[...] * conv2err
	net.forward(start='pool2', end='fc1')
	net.blobs['fc1'].data[...] = net.blobs['fc1'].data[...] * fc1err
	net.forward(start='relu1')
	correct += sum(net.blobs['score'].data.argmax(1) == net.blobs['label'].data)

test_acc = correct / 5e4
print "Accuray: {0:.16f}".format(test_acc)


