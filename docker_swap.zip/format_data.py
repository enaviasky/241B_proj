import numpy as np
import csv

K = pow(2,31-4)-1


#########Adder data file
nums = []
with open('/docker_swap/data/fc1_mult.csv', 'r') as csvfile:
	data = csv.reader(csvfile,  delimiter=',')
	for [a, b] in data:
		nums.append(int(a)*int(b)/K)
		if (int(a)*int(b)/K > (pow(2, 32)-1)):
			print "you suck"
		

f = open('/docker_swap/data/fc1_add.csv', 'w')

for i in range(len(nums)-80):
	for j in range(79):
		f.write('{},'.format(nums[i+j]))
	f.write('{}\n'.format(nums[i+79]))

f.close()
	

########Multiplier data file
#with open('/docker_swap/data/fc1_unsigned_weights.csv', 'r') as csvfile:
#	weights = csv.reader(csvfile,  delimiter=',').next()

#with open('/docker_swap/data/conv2_unsigned_0.csv', 'r') as csvfile:
#	data = csv.reader(csvfile,  delimiter=',').next()

#f = open('/docker_swap/data/fc1_mult.csv', 'w')

#linenum = 0;
#for i in range(1):
#	for w in weights:
#		f.write('{},{}\n'.format(w,data[linenum]))
#		linenum = linenum+1

#for w in weights[:100000]:
#		f.write('{},{}\n'.format(w,data[linenum]))
#		linenum = linenum+1

#f.close()

#print linenum


